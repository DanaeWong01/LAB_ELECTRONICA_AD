#include <Arduino.h>
#include "WiFi.h"
#include "ESPAsyncWebServer.h"

#define PIN_ADC 34     //

//contrasena y nombre de la wifi
const char* ssid = "WIFII_espe"; //nombre de la wifi
const char* password = "espe_G16"; //contrasena de la wifi

// Create AsyncWebServer object on port 80
AsyncWebServer server(80);

Serial.print("IP del servidor: ");
Serial.println(WiFi.softAPIP());

//funcion para leer la temperatura del sensor
float read_TEMPERATURA(){
  float pin_read = analogRead(PIN_ADC);
  float Vt = ((float)pin_read)*3.3/4095.0;
  float temperatura = TEMP_SLOPE * Vt + TEMP_OFFSET;
  return temperatura;
}

const char index_html[] PROGMEM = R"rawliteral(
<!DOCTYPE HTML><html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
  <style>
    html {
     font-family: Arial;
     display: inline-block;
     margin: 0px auto;
     text-align: center;
    }
    h2 { font-size: 3.0rem; }
    p { font-size: 3.0rem; }
    .units { font-size: 1.2rem; }
    .dht-labels{
      font-size: 1.5rem;
      vertical-align:middle;
      padding-bottom: 15px;
    }
  </style>
</head>
<body>
  <h2>ESP32 DHT Server</h2>
  <p>
    <i class="fas fa-thermometer-half" style="color:#059e8a;"></i> 
    <span class="dht-labels">Temperature</span> 
    <span id="temperature">%TEMPERATURE%</span>
    <sup class="units">&deg;C</sup>
  </p>
  <p>
    <i class="fas fa-tint" style="color:#00add6;"></i> 
    <span class="dht-labels">Humidity</span>
    <span id="humidity">%HUMIDITY%</span>
    <sup class="units">&percnt;</sup>
  </p>
</body>
<script>
setInterval(function ( ) {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("temperature").innerHTML = this.responseText;
    }
  };
  xhttp.open("GET", "/temperature", true);
  xhttp.send();
}, 10000 ) ;

</script>
</html>)rawliteral";

String processor(const String& var){
  //Serial.println(var);
  if(var == "Temperatura: "){
    return read_TEMPERATURA();
  }
  return String();
}

void setup(){
  // Serial port for debugging purposes
  Serial.begin(115200);
  
  // Connect to Wi-Fi
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(1000);
    Serial.println("Conectando a WiFi..");
  }

  // Print ESP32 Local IP Address
  Serial.println(WiFi.localIP());

  // Route for root / web page
  server.on("/", HTTP_GET, [](AsyncWebServerRequest *request){
    request->send_P(200, "text/html", index_html, processor);
  });
  server.on("/Temperatura: ", HTTP_GET, [](AsyncWebServerRequest *request){
    request->send_P(200, "text/plain", read_TEMPERATURA().c_str());
  });

  // Start server
  server.begin();
}
 
void loop(){
  
}
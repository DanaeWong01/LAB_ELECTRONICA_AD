#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <LittleFS.h>
#include <ESPAsyncWebServer.h>
#include <AsyncTCP.h>
#include <web.h> // la libreria que creamos
#include <LCD.h> //la que creamos para la pantalla
#include <adc.h> // la libreria para medir el voltaje y determinar la temperaura desde el adc

// variables del sistema
float temperatura = 25.0;
float referencia = 35.0;
float potencia = 2.4; // valor de prueba

// parametros del controlador PI
float kp = 2.0;
float ki = 0.5;

// tiempo de actualizacion
unsigned long tiempoAnterior = 0;
const unsigned long intervalo = 1000; // 1 segundo


void setup() {

    Serial.begin(115200);

    // inicializamos los modulos
    lcd_init();  // pantalla LCD
    adc_init();  // sensor ADC
    web_init();  // servidor web y WiFi

}


void loop() {

    // actualizamos las mediciones cada segundo
    if (millis() - tiempoAnterior >= intervalo) {

        tiempoAnterior = millis();

        // 1. Leemos el voltaje del ADC
        float voltajeMedido = voltaje();

        // 2. Convertimos el voltaje a temperatura
        temperatura = temperatura_adc(voltajeMedido);

        // 3. Obtenemos los parametros actuales desde la web
        web_parametros(kp, ki, referencia);

        // 4. Actualizamos los datos del servidor web
        web_mediciones(temperatura, potencia);

        // 5. Mostramos los valores en la LCD
        lcd_update(temperatura, referencia, potencia);

        // 6. Mostramos los valores en el monitor serie
        Serial.print("Voltaje ADC: ");
        Serial.print(voltajeMedido, 3);
        Serial.print(" V | Temperatura: ");
        Serial.print(temperatura, 1);
        Serial.print(" C | Referencia: ");
        Serial.print(referencia);
        Serial.print(" C | Kp: ");
        Serial.print(kp);
        Serial.print(" | Ki: ");
        Serial.println(ki);
    }
}

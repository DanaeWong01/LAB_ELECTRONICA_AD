
#include <Arduino.h>
#include "LCD.h"   // libreria para la pantalla LCD
#include "pgweb.h" // libreria para el servidor web
#include "adc.h"   // libreria para leer el voltaje y calcular temperatura

// variables del sistema
float temperatura = 25.0;
float referencia = 35.0;
float potencia = 2.4; // valor de prueba

// parametros del controlador PI
float kp = 2.0;
float ki = 0.5;

// tiempo de actualizacion
unsigned long tiempoAnterior = 0;
const unsigned long intervalo = 1000; // 1 segundo


void setup() {

    Serial.begin(115200);
    delay(500);

    // inicializamos la pantalla LCD
    lcd_init();
    lcd_print_line(0, "Iniciando...");
    lcd_print_line(1, "ESP32");

    // inicializamos el ADC
    adc_init();

    // inicializamos el servidor web
    web_init();

    Serial.println("Sistema inicializado");
}


void loop() {

    // actualizamos las mediciones cada segundo
    if (millis() - tiempoAnterior >= intervalo) {

        tiempoAnterior = millis();

        // 1. Leemos el voltaje desde el ADC
        float voltajeMedido = voltaje();

        // 2. Convertimos el voltaje a temperatura
        temperatura = temperatura_adc(voltajeMedido);

        // 3. Obtenemos los parametros desde la web
        web_parametros(kp, ki, referencia);

        // 4. Actualizamos las mediciones de la web
        web_mediciones(temperatura, potencia);

        // 5. Actualizamos la pantalla LCD
        lcd_update(temperatura, referencia, potencia);

        // 6. Mostramos los valores en el monitor serie
        Serial.print("Voltaje ADC: ");
        Serial.print(voltajeMedido, 3);

        Serial.print(" V | Temperatura: ");
        Serial.print(temperatura, 1);

        Serial.print(" C | Referencia: ");
        Serial.print(referencia);

        Serial.print(" C | Kp: ");
        Serial.print(kp);

        Serial.print(" | Ki: ");
        Serial.println(ki);

        // verificamos el rango esperado del ADC
        if (voltajeMedido < 0.3 || voltajeMedido > 3.0) {
            Serial.println("voltaje fuera de rango");
        }
    }
}

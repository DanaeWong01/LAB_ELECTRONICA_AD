`timescale 1ns / 1ps
// M�dulo genera la se�al de salida seg�n lo que le llega de la memoria y el indicador del semiciclo actual
// se encarga de generar el seno a partir de los datos en memoria
module sinusoide(
    //entradas
    input clk,
    input rst,
    input nota_activa,
    input [8:0] posicion, //posicion entregada desde el gen de frecuencias
    input [7:0] ROM_data, //se�al para el dato en la rom
    
    output reg [6:0] ROM_addr, // es la direccion misma a la que accedemos de la ROM
    output reg [7:0] wave
    );
    
    reg semi_pos; //se�al para indicar el semiciclo positivo o negativo
    // revisamos la direccion de la rom
    // Determina la direccion a la que accederemos de la ROM
    always@(*) begin
        if (posicion[7])
            ROM_addr = ~posicion[6:0];
        else
            ROM_addr = posicion[6:0];
    end
    // determina el semiciclo 
    always @(posedge clk) begin
        if (rst)
            semi_pos <= 1'b1;
        else
            semi_pos <= ~posicion[8];
    end
    
    // generamos la sinusoide completa con los datos en las direcciones de la ROM
    always @(posedge clk) begin
        if (rst)
            wave <= 8'd128;
        else if (!nota_activa)
            wave <= 8'd128;
        else begin
            if (semi_pos)
                wave <= 8'd128 + (ROM_data >> 1);
            else 
                wave <= 8'd128 - (ROM_data >> 1);
        end

    end 

endmodule

`timescale 1ns / 1ps
// Este modulo debe encargarse de interpretar lo recibido del teclado
// si se presiona o suelta una tecla, y decidir luego que mandar

module deco_teclado(
    input clk,
    input rst,
    input [7:0] msg,
    input msg_ready,
    
    output reg[7:0] tecla_presionada,
    output reg nota_activa
    );

    reg nota_libre;
    
    always @(posedge clk) begin 
        if (rst) begin
            tecla_presionada <= 8'd0;
            nota_activa <= 1'b0;
            nota_libre <= 1'b0;
        end
        else if (msg_ready) begin
            // cuando se suelta una tecla, el teclado env�a un mensaje F0 para indicar que se solt�
            // y luego env�a nuevamnete la tecla que se solt�
            // si se suelta la tecla, entonces llega un mensaje espec�fico para indicarlo
            if (msg == 8'hF0) begin
                nota_libre <= 1'b1;
            end
            // si se solt� la tecla, entonces
            else if (nota_libre) begin
                nota_libre <= 1'b0;
                if (msg == tecla_presionada)
                    nota_activa <= 1'b0; //desactiva la nota que estaba activa
            end
            
            else begin // recibimos una tecla, una nota valida
                case (msg)
                    // Q W E R T Y U I O P
                    8'h15, 8'h1D, 8'h24, 8'h2D,8'h2C, 
                    8'h35, 8'h3C, 8'h43, 8'h44, 8'h4D,
                    // A S D F G H J K L
                    8'h1C, 8'h1B, 8'h23, 8'h2B, 8'h34, 
                    8'h33, 8'h3B, 8'h42, 8'h4B,
                    // Z X C V B
                    8'h1A, 8'h22, 8'h21, 8'h2A,
                    8'h32: begin
                        tecla_presionada <= msg;
                        nota_activa <= 1'b1; // mientras el mensaje sea valido
                        // es porque la tecla est� presionada y se mantiene nota_activa
                    end
                 endcase
            end
        end
    end
endmodule

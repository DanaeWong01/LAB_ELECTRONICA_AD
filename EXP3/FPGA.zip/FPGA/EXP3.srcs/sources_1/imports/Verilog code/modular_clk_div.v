`timescale 1ns / 1ps

module modular_clk_div #(parameter N=25000)(
        input clk,
        input rst,
        output reg salto
    );
    
    // Hago un contador con suficientes bits para representar el parametro
    reg [$clog2(N)-1:0] count;
    
    always @(posedge(clk) or posedge(rst)) begin
        if (rst) begin
            count <= 0;
            salto <= 0;
        end
        else if (count >= N-1) begin
            count <= 0;
            salto <= 1'b1;
        end
        
        else begin
            count <= count+1;
            salto <= 1'b0;
        end
    end
    
endmodule

`timescale 1ns / 1ps

module esp3_TB;

    // Se�ales de entrada
    reg clk_0;
    reg rst_0;

    // Se�al de salida
    wire [7:0] wave_0;

    // Instancia del DUT (Design Under Test)
    exp3_wrapper uut (
        .clk_0(clk_0),
        .rst_0(rst_0),
        .wave_0(wave_0)
    );

    // Reloj de 100 MHz: periodo de 10 ns
    initial begin
        clk_0 = 0;
        forever #5 clk_0 = ~clk_0;
    end

    // Secuencia de simulaci�n
    initial begin

        // Inicializaci�n
        rst_0 = 1;

        // Mantener reset durante 100 ns
        #100;
        rst_0 = 0;

        // Observar la se�al durante 20 ms
        // (2000000 ciclos de reloj de 100 MHz)
        #20_000_000;

        // Finalizar simulaci�n
        $finish;
    end

    // Monitor de se�ales
    initial begin
        $monitor("Tiempo = %0t ns | rst = %b | wave = %d",
                  $time, rst_0, wave_0);
    end

endmodule